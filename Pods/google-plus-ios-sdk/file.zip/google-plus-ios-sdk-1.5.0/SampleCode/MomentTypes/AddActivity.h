#import "Activity.h"

@interface AddActivity : Activity

@end
