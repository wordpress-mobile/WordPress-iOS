#import "Activity.h"

@interface DiscoverActivity : Activity

@end
